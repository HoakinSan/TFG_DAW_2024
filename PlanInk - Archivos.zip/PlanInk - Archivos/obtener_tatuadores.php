<?php
session_start();
include 'db.php'; // Asegúrate de que el path es correcto a tu archivo de conexión

header('Content-Type: application/json');

// Verifica si el usuario está logueado
if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['success' => false, 'error' => 'Usuario no autenticado']);
    exit;
}

try {
    $query = "SELECT id_usuario, nombre, apellido1 FROM usuarios WHERE id_tipo = 1";
    $stmt = $pdo->query($query);
    $tatuadores = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['success' => true, 'tatuadores' => $tatuadores]);
} catch (PDOException $e) {
    echo json_encode(['success' => false, 'error' => 'Error al obtener los tatuadores: ' . $e->getMessage()]);
}
?>


