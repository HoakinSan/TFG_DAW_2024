<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LogIn</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div id="login-container">
        <h2>Login usuario</h2>
        
        <?php 
            session_start(); // Asegúrate de que la sesión esté iniciada
            if (isset($_SESSION['error_login'])): 
        ?>
            <div class="error-message">
                <?php 
                echo $_SESSION['error_login'];
                unset($_SESSION['error_login']); // Limpia el mensaje después de mostrarlo.
                ?>
            </div>
        <?php 
            endif; 
        ?>

        <form action="login.php" method="post">
            <div class="form-group">
                <label for="correo_electronico">Correo electrónico:</label>
                <input type="email" id="correo_electronico" name="correo_electronico" required>
            </div>
            <div class="form-group">
                <label for="contrasena">Contraseña:</label>
                <input type="password" id="contrasena" name="contrasena" required>
            </div>
            
            <input type="submit" value="Iniciar sesión">
        </form>
    </div>
</body>
</html>

