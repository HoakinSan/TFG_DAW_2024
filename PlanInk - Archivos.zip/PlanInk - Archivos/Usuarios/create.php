<?php
include 'db.php';

$nombre = $_POST['nombre'];
$apellido1 = $_POST['apellido1'];
$apellido2 = $_POST['apellido2'];
$fecha_nacimiento = $_POST['fecha_nacimiento'];
$correo_electronico = $_POST['correo_electronico'];
$contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT); // Encripta la contraseña
$id_tipo = $_POST['id_tipo'];

try {
    $sql = "INSERT INTO usuarios (nombre, apellido1, apellido2, fecha_nacimiento, correo_electronico, contrasena, id_tipo) VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$nombre, $apellido1, $apellido2, $fecha_nacimiento, $correo_electronico, $contrasena, $id_tipo]);

    echo("<script>console.log('Usuario registrado con éxito');</script>");
} catch (PDOException $e) {
    echo "Error al registrar usuario: " . $e->getMessage();
}

// Tras insertar al usuario, redirigir al login
header('Location: inicio.php');
exit();
