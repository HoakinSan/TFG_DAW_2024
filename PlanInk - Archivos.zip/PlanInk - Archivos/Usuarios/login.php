<?php
session_start();
include 'db.php';

// Verifica que el formulario de inicio de sesión ha sido enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $correo = isset($_POST['correo_electronico']) ? $_POST['correo_electronico'] : '';
    $contrasena = isset($_POST['contrasena']) ? $_POST['contrasena'] : '';

    // Consulta a la base de datos para verificar las credenciales
    $query = "SELECT * FROM usuarios WHERE correo_electronico = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$correo]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario && password_verify($contrasena, $usuario['contrasena'])) {
        // Establece los datos del usuario en la sesión
        $_SESSION['id_usuario'] = $usuario['id_usuario'];
        $_SESSION['nombre'] = $usuario['nombre'];
        $_SESSION['apellido1'] = $usuario['apellido1'];
        $_SESSION['id_tipo'] = $usuario['id_tipo'];

        // Redirige al usuario según su tipo
        switch ($_SESSION['id_tipo']) {
            case 1: // Tatuador
                header('Location: ../Calendario_Cliente/prueba3/prueba3.php');
                break;
            case 2: // Cliente
                header('Location: ../Calendario_Cliente/prueba3/prueba3.php');
                break;
            case 3: // Gestor
                header('Location: pagina_gestor.php');
                break;
            default:
                header('Location: pagina_principal.php');
                break;
        }
        exit();
    } else {
        // Error de inicio de sesión
        $_SESSION['error_login'] = 'Credenciales inválidas.';
        header('Location: login.php');
        exit();
    }
} else {
    // Si no es una solicitud POST, redirigir al formulario de inicio de sesión
    header('Location: login.php');
    exit();
}
?>


