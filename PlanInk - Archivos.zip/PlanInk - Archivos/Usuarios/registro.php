<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de usuario</title>
    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <div id="registro-container">
        <h2>Registro de usuario</h2>

        <form action="create.php" method="POST">
            <div class="form-group">
                <label for="fnombre">Nombre:</label>
                <input type="text" name="nombre" required>
            </div>
            <div class="form-group">
                <label for="fapellido1">Primer apellido:</label>
                <input type="text" name="apellido1">
            </div>
            <div class="form-group">
                <label for="fapellido2">Segundo apellido:</label>
                <input type="text" name="apellido2">
            </div>
            <div class="form-group">
                <label for="ffecha">Fecha de nacimiento:</label>
                <input type="date" name="fecha_nacimiento" required>
            </div>
            <div class="form-group">
                <label for="fcorreo">Correo electrónico:</label>
                <input type="email" name="correo_electronico" required>
            </div>
            <div class="form-group">
                <label for="fpassword">Contraseña:</label>
                <input type="password" name="contrasena" required>
            </div>
            <div class="form-group">
                <label for="ftipo">Tipo de usuario:</label>
                <select name="id_tipo" required>
                    <option value="1">Tatuador</option>
                    <option value="2">Cliente</option>
                    <option value="3">Gestor</option>
                </select>
            </div>

            <input type="submit" value="Registrar">
        </form>
    </div>

</body>

<script src="js/script.js"></script>

</html>
