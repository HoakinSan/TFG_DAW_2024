<?php
$host = 'localhost'; // Host de la base de datos
$db = 'calendario-web-v2'; // Nombre de la base de datos
$user = 'josito'; // Usuario de la base de datos
$pass = 'admin'; // Contraseña del usuario de la base de datos
$charset = 'utf8mb4'; // Un conjunto de caracteres común y recomendado

// Construye la cadena DSN (Data Source Name)
$dsn = "mysql:host=$host;dbname=$db;charset=$charset";

// Opciones recomendadas para la conexión PDO
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES   => false,
];

// Intenta crear la conexión PDO
try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    throw new \PDOException($e->getMessage(), (int)$e->getCode());
}
?>