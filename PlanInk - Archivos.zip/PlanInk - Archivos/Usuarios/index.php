<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Selección</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div id="login-container">
        <h2>¿Qué quieres hacer?</h2>

        <form id="formSeleccion" method="post">
            <button type="button" onclick="submitForm('inicio.php')">Iniciar sesión</button>
            <button type="button" onclick="submitForm('registro.php')">Registro</button>
        </form>
    </div>

    <script src="js/script.js"></script>
</body>
</html>
