//Función para cambiar de formulario
function submitForm(action) {
    var form = document.getElementById('formSeleccion');
    form.action = action;
    form.submit();
}