<?php
session_start();
include 'db.php'; // Asegúrate de que el path es correcto a tu archivo de conexión

header('Content-Type: application/json');

$id_tatuador = isset($_GET['id_tatuador']) ? $_GET['id_tatuador'] : null;

if ($id_tatuador) {
    $query = "SELECT id_disponibilidad, titulo, fecha_inicio, fecha_fin FROM disponibilidad_tatuador WHERE id_tatuador = ?";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id_tatuador]);
} else {
    echo json_encode(['success' => false, 'error' => 'No se proporcionó ID de tatuador']);
    exit;
}

$disponibilidad = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($disponibilidad) {
    echo json_encode(['success' => true, 'disponibilidad' => $disponibilidad]);
} else {
    echo json_encode(['success' => false, 'error' => 'No se encontró disponibilidad']);
}
?>




