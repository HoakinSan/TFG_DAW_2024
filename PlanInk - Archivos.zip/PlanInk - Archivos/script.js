// Obtener referencias a los elementos del DOM
const calendar = document.querySelector(".calendar"),
    date = document.querySelector(".date"),
    daysContainer = document.querySelector(".days"),
    prev = document.querySelector(".prev"),
    next = document.querySelector(".next"),
    todayBtn = document.querySelector(".today-btn"),
    gotoBtn = document.querySelector(".goto-btn"),
    dateInput = document.querySelector(".date-input"),
    eventDay = document.querySelector(".event-day"),
    eventDate = document.querySelector(".event-date"),
    eventsContainer = document.querySelector(".events"),
    addEventBtn = document.querySelector(".add-event"),
    addEventWrapper = document.querySelector(".add-event-wrapper"),
    addEventCloseBtn = document.querySelector(".add-event-header .close"),
    addEventTitle = document.querySelector(".event-name"),
    addEventFrom = document.querySelector(".event-time-from"),
    addEventTo = document.querySelector(".event-time-to"),
    addEventSubmit = document.querySelector(".add-event-btn"),
    addEventTatuador = document.querySelector(".tatuador-select"),
    addEventCliente = document.querySelector(".cliente-name"),
    addAvailabilityBtn = document.querySelector(".add-availability"),
    addAvailabilityWrapper = document.querySelector(".add-availability-wrapper"),
    addAvailabilityCloseBtn = document.querySelector(
        ".add-availability-header .close"
    ),
    addAvailabilityTitle = document.querySelector(".availability-title"),
    addAvailabilityFrom = document.querySelector(".availability-start"),
    addAvailabilityTo = document.querySelector(".availability-end"),
    addAvailabilitySubmit = document.querySelector(".add-availability-btn"),
    addEventArtistBtn = document.querySelector(".add-event-artist"),
    addEventArtistWrapper = document.querySelector(".add-event-artist-wrapper"),
    addEventArtistCloseBtn = document.querySelector(
        ".add-event-artist-header .close"
    ),
    addEventArtistTitle = document.querySelector(".add-event-artist .event-name"),
    addEventArtistFrom = document.querySelector(
        ".add-event-artist .event-time-from"
    ),
    addEventArtistTo = document.querySelector(".add-event-artist .event-time-to"),
    addEventArtistCliente = document.querySelector(
        ".add-event-artist .cliente-name"
    ),
    addEventArtistSubmit = document.querySelector(".add-event-artist-btn");

// Variables globales
let today = new Date();
let activeDay;
let month = today.getMonth();
let year = today.getFullYear();

const months = [
    "Enero",
    "Febrero",
    "Marzo",
    "Abril",
    "Mayo",
    "Junio",
    "Julio",
    "Agosto",
    "Septiembre",
    "Octubre",
    "Noviembre",
    "Diciembre",
];

const dayNames = {
    Mon: "Lunes",
    Tue: "Martes",
    Wed: "Miércoles",
    Thu: "Jueves",
    Fri: "Viernes",
    Sat: "Sábado",
    Sun: "Domingo",
};

const eventsArr = [];
console.log(eventsArr);

// Llamada para cargar eventos
document.addEventListener("DOMContentLoaded", loadEvents);

//allow 50 chars in eventtitle
addEventTitle.addEventListener("input", (e) => {
    addEventTitle.value = addEventTitle.value.slice(0, 60);
});

function defineProperty() {
    var osccred = document.createElement("div");
    osccred.style.position = "absolute";
    osccred.style.bottom = "0";
    osccred.style.right = "0";
    osccred.style.fontSize = "10px";
    osccred.style.color = "#ccc";
    osccred.style.fontFamily = "sans-serif";
    osccred.style.padding = "5px";
    osccred.style.background = "#8BF8A7";
    osccred.style.borderTopLeftRadius = "5px";
    osccred.style.borderBottomRightRadius = "5px";
    osccred.style.boxShadow = "0 0 5px #ccc";
    document.body.appendChild(osccred);
}

defineProperty();

//allow only time in eventtime from and to
addEventFrom.addEventListener("input", (e) => {
    addEventFrom.value = addEventFrom.value.replace(/[^0-9:]/g, "");
    if (addEventFrom.value.length === 2) {
        addEventFrom.value += ":";
    }
    if (addEventFrom.value.length > 5) {
        addEventFrom.value = addEventFrom.value.slice(0, 5);
    }
});

addEventTo.addEventListener("input", (e) => {
    addEventTo.value = addEventTo.value.replace(/[^0-9:]/g, "");
    if (addEventTo.value.length === 2) {
        addEventTo.value += ":";
    }
    if (addEventTo.value.length > 5) {
        addEventTo.value = addEventTo.value.slice(0, 5);
    }
});

// Función para eliminar el evento cuando se hace clic en el evento
eventsContainer.addEventListener("click", (e) => {
    const eventElement = e.target.closest('.event');
    if (eventElement && confirm("¿Está seguro de que desea eliminar este evento?")) {
        const eventId = eventElement.getAttribute('data-event-id');
        if (!eventId) {
            console.error("No se encontró el ID del evento.");
            alert("Error: No se encontró el ID del evento.");
            return;
        }

        fetch('delete.php', {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ id: eventId }),
        })
        .then(response => {
            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            if (data.success) {
                alert("Evento eliminado correctamente");
                eventElement.remove(); // Eliminar el elemento del DOM

                // Actualizar eventos y recargar calendario
                loadEvents();
            } else {
                alert("Error al eliminar el evento: " + data.error);
            }
        })
        .catch(error => {
            console.error("Error:", error);
            alert("Error al eliminar el evento");
        });
    }
});




function convertTime(time) {
    //convert time to 24 hour format
    let timeArr = time.split(":");
    let timeHour = timeArr[0];
    let timeMin = timeArr[1];
    let timeFormat = timeHour >= 12 ? "PM" : "AM";
    timeHour = timeHour % 12 || 12;
    time = timeHour + ":" + timeMin + " " + timeFormat;
    return time;
}

// Función para cargar tatuadores y llenar el select solo si es un cliente
function loadTatuadores() {
    fetch("obtener_tatuadores.php")
        .then((response) => response.json())
        .then((data) => {
            if (data.success) {
                const tatuadorSelect = document.querySelector(".tatuador-select");
                if (tatuadorSelect) {
                    tatuadorSelect.innerHTML =
                        '<option value="">Selecciona un tatuador</option>'; // Limpia cualquier opción existente

                    data.tatuadores.forEach((tatuador) => {
                        const option = document.createElement("option");
                        option.value = tatuador.id_usuario;
                        option.textContent = `${tatuador.nombre} ${tatuador.apellido1}`;
                        tatuadorSelect.appendChild(option);
                    });
                } else {
                    console.error("Elemento select .tatuador-select no encontrado.");
                }
            } else {
                console.error("Error al cargar tatuadores: ", data.error);
            }
        })
        .catch((error) => {
            console.error("Error al cargar tatuadores: ", error);
        });
}








//                          ..,,:ii1,
//               .,::;;;;:::;;;;;iiii:,,,,.
//             ,;i11i;;:::::;::::,,:;;;;;ii
//          .:;iii;;;:::::;;;;;;;;;:::::::;
//        .;iii;;;::::;;;;;;;;;;;;;;;;::,,,
//       ,;;::::::;;;;ii;:::::;:::::;;::::,
//      ,::,,::;;iiii11i;;:,,,:::::::::,,,,
//     .::,,:;i111111111;;;,...,,,,,,,.,...
//     .:,::i111tttt11ii;:;:,.  ...,,. ..
//     .,,:i11tttttt11i;;,:::,.   ...
//    ..,,;111tttttt11ii;:,:;:,.   ..
//   .;,.:i111tttt11111111i;;i;,.
//    ,..,;iiiiiiii;;;;;ii11iii:,.
//    ...,,,,:;ii;:,,,,,::;;iii;,,...
//   .,..,,,,.:11i;:,,:,..,::;i;,,.,...
//   ... :iiii1Lft111ii;;;i11tt1::,,,...
//   ....;tfffCCLfffffffffLLfft1::,,,...
//  ,,...iffffLfffftfLLLLLLffft1:,,:,.....
//  :,,,,;1111ii;iii1tffffttt11i:,,:,......
//  ,;:::,;ii11iiii11iii1iiiiiii::::,......
//   ...,,.,;ii;;;;;;;:;;iiiiii;:::,,,,...
//          .:1i;;;;;iiiiiiiii;::::::,,..
//            ;tttt11111iiii;;;::::::,,.
//            .;11ttt111iiii;;;::::::::,...
//              .,::i1ii;;;::::::;;ii;:::,,
//                 .;i;;;;;;;;;;i1tfffti;;,





let availableDays = new Set();
let idTatuador = null; // Define idTatuador como variable global

document.addEventListener("DOMContentLoaded", () => {
    loadTatuadores();
    loadEvents();

    if (idTipo === "2") {
        setupClienteUI();
    } else if (idTipo === "1") {
        setupTatuadorUI();
        showAgendasAbiertas();
    }
});

function setupClienteUI() {
    const addEventBtn = document.querySelector(".add-event");
    const addEventWrapper = document.querySelector(".add-event-wrapper");
    const addEventCloseBtn = document.querySelector(".add-event-header .close");
    const addEventSubmit = document.querySelector(".add-event-btn");
    const tatuadorSelect = document.querySelector(".tatuador-select");
    const tatuadorNameInput = document.querySelector(".tatuador-name");

    //function to add event
    addEventBtn.addEventListener("click", () => {
        addEventWrapper.classList.toggle("active");
    });

    addEventCloseBtn.addEventListener("click", () => {
        addEventWrapper.classList.remove("active");
    });

    document.addEventListener("click", (e) => {
        if (e.target !== addEventBtn && !addEventWrapper.contains(e.target)) {
            addEventWrapper.classList.remove("active");
        }
    });

    if (tatuadorSelect) {
        tatuadorSelect.addEventListener("change", (e) => {
            const idTatuador = e.target.value;
            if (idTatuador) {
                const selectedOption =
                    tatuadorSelect.options[tatuadorSelect.selectedIndex];
                tatuadorNameInput.value = selectedOption.text;
                tatuadorNameInput.readOnly = true;
                loadAvailability(idTatuador);
            } else {
                tatuadorNameInput.value = "";
                tatuadorNameInput.readOnly = false;
                clearAvailability(); // Función para limpiar la disponibilidad mostrada
            }
        });
    }

    // Función para agregar un evento de cliente
    addEventSubmit.addEventListener("click", () => {
        const eventTitle = addEventTitle.value;
        const eventTimeFrom = addEventFrom.value;
        const eventTimeTo = addEventTo.value;
        const idTatuador = tatuadorSelect.value;
        const nombreTatuador = tatuadorNameInput.value;

        if (
            eventTitle === "" ||
            eventTimeFrom === "" ||
            eventTimeTo === "" ||
            nombreTatuador === ""
        ) {
            alert("Por favor, completa todos los campos necesarios");
            return;
        }

        // Verificar formato de hora correcto 24 horas
        const timeFromArr = eventTimeFrom.split(":");
        const timeToArr = eventTimeTo.split(":");
        if (
            timeFromArr.length !== 2 ||
            timeToArr.length !== 2 ||
            isNaN(timeFromArr[0]) ||
            isNaN(timeFromArr[1]) ||
            isNaN(timeToArr[0]) ||
            isNaN(timeToArr[1]) ||
            timeFromArr[0] > 23 ||
            timeFromArr[1] > 59 ||
            timeToArr[0] > 23 ||
            timeToArr[1] > 59
        ) {
            alert("Formato de hora no válido");
            return;
        }

        const timeFrom = new Date(`${year}-${(month + 1).toString().padStart(2, "0")}-${activeDay.toString().padStart(2, "0")}T${eventTimeFrom}:00`).getTime();
        const timeTo = new Date(`${year}-${(month + 1).toString().padStart(2, "0")}-${activeDay.toString().padStart(2, "0")}T${eventTimeTo}:00`).getTime();

        // Verificar superposición de eventos
        if (isOverlapping(timeFrom, timeTo)) {
            alert("La cita se superpone con otra existente. Por favor, elige un horario diferente.");
            return;
        }

        if (idTatuador && !isWithinAvailability(timeFrom, timeTo)) {
            alert("La cita está fuera de la disponibilidad del tatuador seleccionado");
            return;
        }

        const newEvent = {
            title: eventTitle,
            start: new Date(timeFrom).toISOString(),
            end: new Date(timeTo).toISOString(),
            nombre_tatuador: nombreTatuador,
            id_tatuador: idTatuador || null,
            id_cliente: idUsuario,
        };

        fetch("create.php", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(newEvent),
        })
            .then((response) => response.json())
            .then((data) => {
                if (data.success) {
                    alert("Evento añadido correctamente");
                    const eventDate = new Date(newEvent.start);
                    eventsArr.push({
                        day: eventDate.getDate(),
                        month: eventDate.getMonth() + 1,
                        year: eventDate.getFullYear(),
                        events: [newEvent],
                    });
                    updateEvents(activeDay);
                    addEventWrapper.classList.remove("active");
                    addEventTitle.value = "";
                    addEventFrom.value = "";
                    addEventTo.value = "";
                    tatuadorSelect.value = "";
                    tatuadorNameInput.value = "";
                    tatuadorNameInput.readOnly = false;
                    const activeDayEl = document.querySelector(".day.active");
                    if (!activeDayEl.classList.contains("event")) {
                        activeDayEl.classList.add("event");
                    }
                } else {
                    alert(data.error || "Error al añadir el evento");
                }
            })
            .catch((error) => {
                console.error("Error:", error);
                alert("Error al añadir el evento");
            });
    });

}

function isOverlapping(newEventStart, newEventEnd) {
    for (const event of eventsArr) {
        for (const eventDetail of event.events) {
            const existingEventStart = new Date(eventDetail.start).getTime();
            const existingEventEnd = new Date(eventDetail.end).getTime();
            if (
                (newEventStart >= existingEventStart && newEventStart < existingEventEnd) ||
                (newEventEnd > existingEventStart && newEventEnd <= existingEventEnd) ||
                (newEventStart <= existingEventStart && newEventEnd >= existingEventEnd)
            ) {
                return true;
            }
        }
    }
    return false;
}


// Función para verificar si la cita está dentro de la disponibilidad
function isWithinAvailability(timeFrom, timeTo) {
    let withinAvailability = false;

    disponibilidadTatuador.forEach((availability) => {
        const availabilityStart = new Date(availability.fecha_inicio).getTime();
        const availabilityEnd = new Date(availability.fecha_fin).getTime();

        if (timeFrom >= availabilityStart && timeTo <= availabilityEnd) {
            withinAvailability = true;
        }
    });

    return withinAvailability;
}





//                                                    ,iit1;.
//                                                  :fGGGGGGCf;.
//                                                 ;LCfffLCGG08i
//                                                ,GCfffttLGG08C:
//                                                :GLfLftttLCGGC;
//                                                ,Ltftt11ttLC11i
//                                                 1t11ii1t1fLtfi:
//                                                 ,t1i11111fCL11G1:,
//                                                  iL111t1tti;iLGGGGLt;,
//                                              ,it1fGLtt1i;:,itfCGGGG00Gf;.
//                                            :tLGftfCL1i:,::;1tLCCCGGGGGG0L,
//       .;;;;;;;;::::,,,,....               10GCttffCCffttttffLLCCCCCCCLG00Ci
//       .tCCCCGGG000000GGGGCCC1           .tLGCLfffCGGGCffLLLLLLLLLfLCLCGGGGGi
//        iCCCCCCGGG000000888880:          i0ffffff00800CfLLLLLftff1tfLtLCCLCCL.
//        ,LCCCCCGGGG00000000088t         iCGL1ittfG0000CtLfLLftf11ii1t1fLtLCG0i
//         1CCCCCCGGGGG000000008C.     .;f0GLLi;ttfC0000LtffLt1fCLLt111;iifLCGGG:
//         :LCCCCCCGGGG0000000000;    ,fCGCCffi:tfLLG000L1ttf1tLCCCCLLLLtitfttfLf:
//         .tCCCCCCGGGG0000000008f.,:itf11ii;;;:1fftfCCL11ti11tfLLLLLLCGGtLCCftttt,
//          ;CGCCGCGGGGG000000000GtfLCLfi;;;;:,,i11i1iiiitt1iiii1tfffffLCLLffLftft:
//          .tLLLLCCCGGGG000000000tii1111;::;;:,;iii;;i1tt1iiiiiii1tfffLLLLLtfffLf:
//           ...,,,::;;ii11ttfLLLCti1t11iii;:;:,;;;::;iiii;;;;:;;;:::;;11fffLfffft.
//            ..            .....,.itLLLft1i;:,.                ... .....:,,,,:::.
//                 ................,:;:,,...


function setupTatuadorUI() {
    const addEventArtistBtn = document.querySelector(".add-event-artist");
    const addEventArtistWrapper = document.querySelector(".add-event-artist-wrapper");
    const addEventArtistCloseBtn = document.querySelector(".add-event-artist-header .close");
    const addEventArtistSubmit = document.querySelector(".add-event-artist-btn");

    const addAvailabilityBtn = document.querySelector(".add-availability");
    const addAvailabilityWrapper = document.querySelector(".add-availability-wrapper");
    const addAvailabilityCloseBtn = document.querySelector(".add-availability-header .close");
    const addAvailabilitySubmit = document.querySelector(".add-availability-btn");


        addEventArtistBtn.addEventListener("click", () => {
            addEventArtistWrapper.classList.toggle("active");
        });



        addEventArtistCloseBtn.addEventListener("click", () => {
            addEventArtistWrapper.classList.remove("active");
        });


    if (addEventArtistSubmit) {
        addEventArtistSubmit.addEventListener("click", () => {
            const eventTitle = document.querySelector(".add-event-artist-wrapper .event-name").value;
            const eventTimeFrom = document.querySelector(".add-event-artist-wrapper .event-time-from").value;
            const eventTimeTo = document.querySelector(".add-event-artist-wrapper .event-time-to").value;
            const clienteName = document.querySelector(".add-event-artist-wrapper .cliente-name").value;
            const idCliente = clienteName ? obtenerIdCliente(clienteName) : null; // Implementa obtenerIdCliente para obtener el id del cliente si está disponible

            if (eventTitle === "" || eventTimeFrom === "" || eventTimeTo === "" || clienteName === "") {
                alert("Por favor, completa todos los campos necesarios");
                return;
            }

            const timeFromArr = eventTimeFrom.split(":");
            const timeToArr = eventTimeTo.split(":");
            if (
                timeFromArr.length !== 2 ||
                timeToArr.length !== 2 ||
                isNaN(timeFromArr[0]) ||
                isNaN(timeFromArr[1]) ||
                isNaN(timeToArr[0]) ||
                isNaN(timeToArr[1]) ||
                timeFromArr[0] > 23 ||
                timeFromArr[1] > 59 ||
                timeToArr[0] > 23 ||
                timeToArr[1] > 59
            ) {
                alert("Invalid Time Format");
                return;
            }

            const timeFrom = `${year}-${(month + 1).toString().padStart(2, "0")}-${activeDay.toString().padStart(2, "0")}T${eventTimeFrom}:00`;
            const timeTo = `${year}-${(month + 1).toString().padStart(2, "0")}-${activeDay.toString().padStart(2, "0")}T${eventTimeTo}:00`;

            const newEvent = {
                title: eventTitle,
                start: timeFrom,
                end: timeTo,
                nombre_cliente: clienteName,
                id_cliente: idCliente, // Enviar id_cliente si está disponible
                id_tatuador: idUsuario,
            };

            fetch("create_artist.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(newEvent),
            })
                .then((response) => response.json())
                .then((data) => {
                    if (data.success) {
                        alert("Evento añadido correctamente");
                        const [date, time] = timeFrom.split("T");
                        const [year, month, day] = date.split("-");
                        eventsArr.push({
                            day: parseInt(day),
                            month: parseInt(month),
                            year: parseInt(year),
                            events: [newEvent],
                        });
                        updateEvents(activeDay);
                        addEventArtistWrapper.classList.remove("active");
                        document.querySelector(".add-event-artist-wrapper .event-name").value = "";
                        document.querySelector(".add-event-artist-wrapper .event-time-from").value = "";
                        document.querySelector(".add-event-artist-wrapper .event-time-to").value = "";
                        document.querySelector(".add-event-artist-wrapper .cliente-name").value = "";
                        const activeDayEl = document.querySelector(".day.active");
                        if (!activeDayEl.classList.contains("event")) {
                            activeDayEl.classList.add("event");
                        }
                    } else {
                        alert(data.error || "Error al añadir el evento");
                    }
                })
                .catch((error) => {
                    console.error("Error:", error);
                    alert("Error al añadir el evento");
                });
        });
    }


        addAvailabilityBtn.addEventListener("click", () => {
            addAvailabilityWrapper.classList.toggle("active");
        });



        addAvailabilityCloseBtn.addEventListener("click", () => {
            addAvailabilityWrapper.classList.remove("active");
        });


    if (addAvailabilitySubmit) {
        addAvailabilitySubmit.addEventListener("click", () => {
            const availabilityTitle = document.querySelector(".add-availability-wrapper .availability-title").value;
            const availabilityStart = document.querySelector(".add-availability-wrapper .availability-start").value;
            const availabilityEnd = document.querySelector(".add-availability-wrapper .availability-end").value;

            if (availabilityTitle === "" || availabilityStart === "" || availabilityEnd === "") {
                alert("Por favor, completa todos los campos necesarios");
                return;
            }

            const newAvailability = {
                title: availabilityTitle,
                start: availabilityStart,
                end: availabilityEnd,
                id_tatuador: idUsuario,
            };

            fetch("obtener_disponibilidad.php", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(newAvailability),
            })
                .then((response) => response.json())
                .then((data) => {
                    if (data.success) {
                        alert("Disponibilidad añadida correctamente");
                        if (addAvailabilityWrapper) {
                            addAvailabilityWrapper.classList.remove("active");
                        }
                        loadAvailability(); // Recargar la disponibilidad después de añadirla
                    } else {
                        alert(data.error || "Error al añadir la disponibilidad");
                    }
                })
                .catch((error) => {
                    console.error("Error:", error);
                    alert("Error al añadir la disponibilidad");
                });
        });
    }

    loadAvailability(idUsuario); // Cargar disponibilidad al inicializar la interfaz del tatuador
    // Cargar agendas abiertas al cargar la interfaz del tatuador
    loadOpenAgendas(idUsuario);

    function obtenerIdCliente(clienteName) {
        // Aquí puedes implementar la lógica para obtener el id del cliente basado en el nombre
        // Por ejemplo, puedes hacer una solicitud AJAX para buscar el id del cliente en la base de datos
        return null; // Retorna null por defecto
    }
}

function showAgendasAbiertas() {
    const agendasAbiertasContainer = document.getElementById("agendas-abiertas");
    if (agendasAbiertasContainer) {
        agendasAbiertasContainer.style.display = "block"; // Mostrar la sección de agendas abiertas
        loadOpenAgendas(idUsuario); // Cargar las agendas abiertas del tatuador
    }
}

function loadOpenAgendas(idTatuador) {
    fetch(`get_disponibilidad.php?id_tatuador=${idTatuador}`)
        .then((response) => response.json())
        .then((data) => {
            if (data.success) {
                const agendasList = document.querySelector(".agendas-list");
                agendasList.innerHTML = "";
                data.disponibilidad.forEach((item) => {
                    const agendaDiv = document.createElement("div");
                    agendaDiv.classList.add("agenda");
                    agendaDiv.setAttribute('data-id', item.id_disponibilidad); // Asignar data-id correctamente

                    const titleDiv = document.createElement("div");
                    titleDiv.classList.add("agenda-title");
                    titleDiv.textContent = item.titulo;

                    const datesDiv = document.createElement("div");
                    datesDiv.classList.add("agenda-dates");

                    // Formatear las fechas al formato dd/mm/aa
                    const startDate = new Date(item.fecha_inicio);
                    const endDate = new Date(item.fecha_fin);

                    const formatDate = (date) => {
                        const day = String(date.getDate()).padStart(2, '0');
                        const month = String(date.getMonth() + 1).padStart(2, '0');
                        const year = String(date.getFullYear()).slice(-2);
                        return `${day}/${month}/${year}`;
                    };

                    datesDiv.textContent = `${formatDate(startDate)} - ${formatDate(endDate)}`;

                    const deleteBtn = document.createElement("button");
                    deleteBtn.classList.add("delete-agenda-btn");
                    deleteBtn.textContent = "Eliminar";
                    deleteBtn.addEventListener("click", () => {
                        const id = agendaDiv.getAttribute('data-id');
                        deleteAgenda(id);
                    });

                    agendaDiv.appendChild(titleDiv);
                    agendaDiv.appendChild(datesDiv);
                    agendaDiv.appendChild(deleteBtn);

                    agendasList.appendChild(agendaDiv);
                });
            } else {
                console.error("Error al cargar las agendas abiertas:", data.error);
            }
        })
        .catch((error) => {
            console.error("Error al cargar las agendas abiertas:", error);
        });
}




function deleteAgenda(id) {
    fetch('delete_disponibilidad.php', {
        method: 'DELETE',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ id: id }),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }
        return response.json();
    })
    .then(data => {
        if (data.success) {
            alert("Disponibilidad eliminada correctamente");
            if (idTatuador) {
                loadOpenAgendas(idTatuador); // Recargar la lista de agendas abiertas
                loadAvailability(idTatuador); // Recargar la disponibilidad en el calendario
                initCalendar(); // Re-inicializa el calendario
            }
        } else {
            alert("Error al eliminar la agenda: " + data.error);
        }
    })
    .catch(error => {
        console.error("Error:", error);
        alert("Error al eliminar la agenda");
    });
}



document.addEventListener("click", (e) => {
    if (
        addAvailabilityWrapper &&
        e.target !== addAvailabilityBtn &&
        !addAvailabilityWrapper.contains(e.target)
    ) {
        addAvailabilityWrapper.classList.remove("active");
    }
    if (
        addEventWrapper &&
        e.target !== addEventBtn &&
        !addEventWrapper.contains(e.target)
    ) {
        addEventWrapper.classList.remove("active");
    }
    if (
        addEventArtistWrapper &&
        e.target !== addEventArtistBtn &&
        !addEventArtistWrapper.contains(e.target)
    ) {
        addEventArtistWrapper.classList.remove("active");
    }
});

function loadEvents() {
    const url =
        idTipo === "1" ? "obtener_eventos_tatuadores.php" : "obtener_eventos.php";

    fetch(url)
        .then((response) => response.json())
        .then((data) => {
            if (data.success) {
                eventsArr.length = 0;
                eventsArr.push(...data.events);
                initCalendar();
            } else {
                console.error("Error al cargar eventos: ", data.error);
            }
        })
        .catch((error) => {
            console.error("Error al cargar eventos: ", error);
        });
}

// Función para limpiar la disponibilidad mostrada en el calendario
function clearAvailability() {
    const availableDaysElements = document.querySelectorAll(".day.available");
    availableDaysElements.forEach((day) => {
        day.classList.remove("available");
    });
    availableDays.clear();
}

// Función para cargar la disponibilidad del tatuador
function loadAvailability(idTatuador) {
    fetch(`get_disponibilidad.php?id_tatuador=${idTatuador}`)
        .then((response) => response.json())
        .then((data) => {
            if (data.success) {
                disponibilidadTatuador = data.disponibilidad;
                applyAvailabilityToCalendar(disponibilidadTatuador);
            } else {
                console.error("Error al cargar la disponibilidad:", data.error);
            }
        })
        .catch((error) => {
            console.error("Error al cargar la disponibilidad:", error);
        });
}

// Función para aplicar la disponibilidad al calendario
function applyAvailabilityToCalendar(disponibilidad) {
    clearAvailability();
    disponibilidad.forEach((item) => {
        const startDate = new Date(item.fecha_inicio);
        const endDate = new Date(item.fecha_fin);

        for (
            let d = new Date(startDate);
            d <= endDate;
            d.setDate(d.getDate() + 1)
        ) {
            const day = d.getDate();
            const month = d.getMonth() + 1;
            const year = d.getFullYear();
            const dateStr = `${year}-${month.toString().padStart(2, "0")}-${day.toString().padStart(2, "0")}`;

            availableDays.add(dateStr);

            const dayElement = document.querySelector(`.day[data-day="${day}-${month}-${year}"]`);
            if (dayElement && !dayElement.classList.contains("event")) {
                dayElement.classList.add("available");
            }
        }
    });
}


function updateHourlyEvents(date) {
    const hourlyEventsContainer = document.querySelector(".hourly-events");
    hourlyEventsContainer.innerHTML = ""; // Limpiar contenido anterior

    // Crear un array de horas
    const hours = Array.from({ length: 24 }, (_, i) => i);

    hours.forEach((hour) => {
        const hourBox = document.createElement("div");
        hourBox.classList.add("hour-box");

        const hourLabel = document.createElement("div");
        hourLabel.classList.add("hour");
        hourLabel.textContent = `${hour.toString().padStart(2, "0")}:00`;

        const eventBoxContainer = document.createElement("div");
        eventBoxContainer.classList.add("event-box-container");

        // Buscar eventos que coincidan con esta hora
        eventsArr.forEach((event) => {
            if (
                date === event.day &&
                month + 1 === event.month &&
                year === event.year
            ) {
                event.events.forEach((eventDetail) => {
                    const startTime = new Date(eventDetail.start);
                    const endTime = new Date(eventDetail.end);

                    if (startTime.getHours() === hour || (startTime.getHours() < hour && endTime.getHours() > hour)) {
                        const eventBox = document.createElement("div");
                        eventBox.classList.add("event-box");

                        const titleDiv = document.createElement("div");
                        titleDiv.classList.add("event-title");
                        titleDiv.textContent = eventDetail.title;

                        const timeDiv = document.createElement("div");
                        timeDiv.classList.add("event-time");
                        timeDiv.textContent = `${startTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} - ${endTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`;

                        eventBox.appendChild(titleDiv);
                        eventBox.appendChild(timeDiv);
                        eventBoxContainer.appendChild(eventBox);
                    }
                });
            }
        });

        hourBox.appendChild(hourLabel);
        hourBox.appendChild(eventBoxContainer);
        hourlyEventsContainer.appendChild(hourBox);
    });

    if (hourlyEventsContainer.innerHTML === "") {
        hourlyEventsContainer.innerHTML = "<p>No hay eventos</p>";
    }
}

// Modificar getActiveDay para actualizar eventos por horas
function getActiveDay(date) {
    const day = new Date(year, month, date);
    const dayNameEnglish = day.toString().split(" ")[0];
    const dayNameSpanish = dayNames[dayNameEnglish];
    eventDay.innerHTML = dayNameSpanish;
    eventDate.innerHTML = `${date} ${months[month]} ${year}`;

    updateHourlyEvents(date); // Actualizar eventos por horas
}

//                                   .:;it1i;:,,..
//                                .:i1tfffLLLf1i;,,,.
//                              .:;;i1tffLfLLCLti:,,,,.
//                            .,,,:iLLLLLffffftti;:,,,,.
//                            :,,,;11i;;i11ii:,,,,,,,,,,,
//                           ,:..,:;,.,,,:;;::,...,,:,,.,.
//                           ;,..,,,:tf1;;;::::::::;;:,..,
//                           ,....,;fLLCCCCLt111tt1;;;,,.,
//                           ....,i1ttffLCCCLfffft1;;::,.,
//                           ....,i11ttfLLLLfffftt1;;:::.,
//                           ::..,;tt1tffLCLLLffffti::::,,
//                           ;i,.:i1ttt1ttffLLfLL1:,,,,,:.
//             .1i:      .....11:;11i;;;::,:;1tt;,,::,,::
//             ;0Ct1:..,Lif1,:ifLf11ii11ii;:;ift::;;;;;;:
//              :t1ti::,:,::,,,iLfLftt1t1ttfCLCC;i1ttf1i:
//               ;11ii:;ii1;f0Ci11fiifLttGGCLLLG1;;i11i;,
//               1Lt1111i...;t1::::,,iLftf1itttf1:::::::.
//             .iC0GGG00C:...  :1;Gi,,iii;itti;;:::,:;;:
//             tftft1iii;:,:;1tfC;:;:;1t1tttttft1;::;::.
//             .1fti;i1ttfLLCG00CffCt,:;;i1ffft1ii;;,,,
//             .LGCffffffffttffftti:,..,,,:i1tfft1;,;;..
//            .;L1tftt1iii111iii:.......,i:,,::::,,:i;...
//           ..Lt:1fLfft11it1,;: ........;t,........ .......
//          .,.G1,i;;;i11ii:.,,,...........,...... ...... ..,..
//         ,,..GG,;;;::;:;i..,:,................,::,..............
//        ,....i@1,;111;it, .,::..............;fLLtf1,...............
//       ,..... t@;:1iiGG, ...:: .............,f00GGC; ................
//      ,....... L8:.18G, ...it1,...............t880G1..................
//     ,..........8L1@C.,;iiitt1iiii:........... t808f ..................
//    ............,:;i..,,::,:,,,,................f08t ...................
//    ,...........    ...  ........................fG; ...............  .,
//   ..............................................,i.................;, .,
//   ,................................................................Lt...,
//  ,............................................................... ;i:...,,
// .,.................................................................  ....,,
// ,.........................................................................,.
// ,..........................................................................,
// ...........................................................................,.
//   ..........................................................................,
//       ......,. ..............................................................,
//              ,................................................................,
//               ,...............................................................,.
//                , ..............................................................,


function updateEvents(date) {
    let events = "";
    eventsArr.forEach((event) => {
        if (
            date === event.day &&
            month + 1 === event.month &&
            year === event.year
        ) {
            event.events.forEach((eventDetail) => {
                const startTime = new Date(eventDetail.start);
                const endTime = new Date(eventDetail.end);

                // Verificar el tipo de usuario y mostrar el nombre correspondiente
                const nombreUsuario =
                    idTipo === "1"
                        ? eventDetail.nombre_cliente
                        : eventDetail.nombre_tatuador;
                const labelUsuario = idTipo === "1" ? "Cliente" : "Tatuador";

                events += `<div class="event" data-event-id="${eventDetail.id}">
                    <div class="title">
                        <i class="fas fa-circle"></i>
                        <h3 class="event-title">${eventDetail.title}</h3>
                    </div>
                    <div class="event-time">
                        <span class="event-time">${startTime.toLocaleTimeString(
                    [],
                    { hour: "2-digit", minute: "2-digit" }
                )} - ${endTime.toLocaleTimeString([], {
                    hour: "2-digit",
                    minute: "2-digit",
                })}</span>
                    </div>
                    <div class="event-usuario">
                        <span class="event-usuario">${labelUsuario}: ${nombreUsuario || ""
                    }</span>
                    </div>
                </div>`;
            });
        }
    });
    if (events === "") {
        events = `<div class="no-event">
            <h3>No Events</h3>
        </div>`;
    }
    eventsContainer.innerHTML = events;
}

function prevMonth() {
    month--;
    if (month < 0) {
        month = 11;
        year--;
    }
    initCalendar();
}

function nextMonth() {
    month++;
    if (month > 11) {
        month = 0;
        year++;
    }
    initCalendar();
}



function gotoDate() {
    const dateArr = dateInput.value.split("/");
    if (dateArr.length === 2) {
        if (dateArr[0] > 0 && dateArr[0] < 13 && dateArr[1].length === 4) {
            month = dateArr[0] - 1;
            year = dateArr[1];
            initCalendar();
            return;
        }
    }
    alert("Fecha no valida");
}


prev.addEventListener("click", prevMonth);
next.addEventListener("click", nextMonth);
gotoBtn.addEventListener("click", gotoDate);



// Inicializar el calendario y aplicar eventos y disponibilidad
function initCalendar() {
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const prevLastDay = new Date(year, month, 0);
    const prevDays = prevLastDay.getDate();
    const lastDate = lastDay.getDate();
    const day = (firstDay.getDay() + 6) % 7;
    const nextDays = 7 - ((lastDay.getDay() + 6) % 7) - 1;

    date.innerHTML = months[month] + " " + year;

    let days = "";

    for (let x = day; x > 0; x--) {
        days += `<div class="day prev-date">${prevDays - x + 1}</div>`;
    }

    for (let i = 1; i <= lastDate; i++) {
        let event = false;
        let available = false;

        eventsArr.forEach((eventObj) => {
            if (
                eventObj.day === i &&
                eventObj.month === month + 1 &&
                eventObj.year === year
            ) {
                event = true;
            }
        });

        const dateStr = `${year}-${(month + 1).toString().padStart(2, "0")}-${i.toString().padStart(2, "0")}`;

        if (availableDays.has(dateStr)) {
            available = true;
        }

        if (
            i === new Date().getDate() &&
            year === new Date().getFullYear() &&
            month === new Date().getMonth()
        ) {
            activeDay = i;
            getActiveDay(i);
            updateEvents(i);
            if (event) {
                days += `<div class="day today active event" data-day="${i}-${month + 1}-${year}">${i}</div>`;
            } else if (available) {
                days += `<div class="day today active available" data-day="${i}-${month + 1}-${year}">${i}</div>`;
            } else {
                days += `<div class="day today active" data-day="${i}-${month + 1}-${year}">${i}</div>`;
            }
        } else {
            if (event) {
                days += `<div class="day event" data-day="${i}-${month + 1}-${year}">${i}</div>`;
            } else if (available) {
                days += `<div class="day available" data-day="${i}-${month + 1}-${year}">${i}</div>`;
            } else {
                days += `<div class="day" data-day="${i}-${month + 1}-${year}">${i}</div>`;
            }
        }
    }

    for (let j = 1; j <= nextDays; j++) {
        days += `<div class="day next-date">${j}</div>`;
    }
    daysContainer.innerHTML = days;
    addListner();

    // Volver a aplicar la disponibilidad después de inicializar el calendario
    if (idTatuador) {
        applyAvailabilityToCalendar(disponibilidadTatuador);
    }
}



// Modificar addListner para actualizar eventos por horas al hacer clic en un día
function addListner() {
    const days = document.querySelectorAll(".day");
    days.forEach((day) => {
        day.addEventListener("click", (e) => {
            getActiveDay(e.target.innerHTML);
            updateEvents(Number(e.target.innerHTML));
            updateHourlyEvents(Number(e.target.innerHTML)); // Actualizar eventos por horas
            activeDay = Number(e.target.innerHTML);
            days.forEach((day) => {
                day.classList.remove("active");
            });
            if (e.target.classList.contains("prev-date")) {
                prevMonth();
                setTimeout(() => {
                    const days = document.querySelectorAll(".day");
                    days.forEach((day) => {
                        if (
                            !day.classList.contains("prev-date") &&
                            day.innerHTML === e.target.innerHTML
                        ) {
                            day.classList.add("active");
                        }
                    });
                }, 100);
            } else if (e.target.classList.contains("next-date")) {
                nextMonth();
                setTimeout(() => {
                    const days = document.querySelectorAll(".day");
                    days.forEach((day) => {
                        if (
                            !day.classList.contains("next-date") &&
                            day.innerHTML === e.target.innerHTML
                        ) {
                            day.classList.add("active");
                        }
                    });
                }, 100);
            } else {
                e.target.classList.add("active");
            }
        });
    });
}

todayBtn.addEventListener("click", () => {
    today = new Date();
    month = today.getMonth();
    year = today.getFullYear();
    initCalendar();
});

dateInput.addEventListener("input", (e) => {
    dateInput.value = dateInput.value.replace(/[^0-9/]/g, "");
    if (dateInput.value.length === 2) {
        dateInput.value += "/";
    }
    if (dateInput.value.length > 7) {
        dateInput.value = dateInput.value.slice(0, 7);
    }
    if (e.inputType === "deleteContentBackward") {
        if (dateInput.value.length === 3) {
            dateInput.value = dateInput.value.slice(0, 2);
        }
    }
});

gotoBtn.addEventListener("click", gotoDate);

initCalendar();

