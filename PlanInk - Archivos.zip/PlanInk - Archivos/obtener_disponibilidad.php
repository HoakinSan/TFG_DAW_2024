<?php
session_start();
include 'db.php'; // Verifica que este es el path correcto a tu archivo de conexión

header('Content-Type: application/json');

// Verifica que el usuario está logueado
if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['error' => 'Usuario no autenticado']);
    exit;
}

$id_tatuador = $_SESSION['id_usuario'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['title'], $data['start'], $data['end'])) {
        echo json_encode(['error' => 'Datos insuficientes']);
        exit;
    }

    $titulo = $data['title'];
    $fecha_inicio = $data['start'];
    $fecha_fin = $data['end'];

    try {
        // Verificar si las nuevas fechas se superponen con alguna disponibilidad existente
        $query = "SELECT * FROM disponibilidad_tatuador WHERE id_tatuador = ? AND (
                    (fecha_inicio <= ? AND fecha_fin >= ?) OR
                    (fecha_inicio <= ? AND fecha_fin >= ?) OR
                    (fecha_inicio >= ? AND fecha_fin <= ?)
                )";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$id_tatuador, $fecha_inicio, $fecha_inicio, $fecha_fin, $fecha_fin, $fecha_inicio, $fecha_fin]);

        if ($stmt->rowCount() > 0) {
            echo json_encode(['error' => 'Las fechas seleccionadas se superponen con una disponibilidad existente.']);
            exit;
        }

        // Insertar la nueva disponibilidad
        $query = "INSERT INTO disponibilidad_tatuador (id_tatuador, titulo, fecha_inicio, fecha_fin) VALUES (?, ?, ?, ?)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$id_tatuador, $titulo, $fecha_inicio, $fecha_fin]);

        echo json_encode(['success' => 'Disponibilidad creada correctamente']);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al crear la disponibilidad: ' . $e->getMessage()]);
    }
}
?>





