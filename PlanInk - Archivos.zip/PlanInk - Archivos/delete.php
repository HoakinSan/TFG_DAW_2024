<?php
session_start();
include 'db.php'; // Verifica que este es el path correcto a tu archivo de conexión

header('Content-Type: application/json');

// Verifica que el usuario está logueado
if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['error' => 'Usuario no autenticado']);
    exit;
}

$id_usuario = $_SESSION['id_usuario'];
$id_tipo = $_SESSION['id_tipo'];

if ($_SERVER['REQUEST_METHOD'] === 'DELETE') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['id'])) {
        echo json_encode(['error' => 'Datos insuficientes']);
        exit;
    }

    $id_cita = $data['id'];

    try {
        // Si el usuario es un cliente
        if ($id_tipo == 2) {
            $query = "UPDATE citas SET is_deleted = TRUE WHERE id_cita = ? AND id_cliente = ?";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$id_cita, $id_usuario]);
        }
        // Si el usuario es un tatuador
        elseif ($id_tipo == 1) {
            $query = "UPDATE citas SET is_deleted = TRUE WHERE id_cita = ? AND id_tatuador = ?";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$id_cita, $id_usuario]);
        } else {
            echo json_encode(['error' => 'No tiene permisos para eliminar citas.']);
            exit;
        }

        if ($stmt->rowCount() > 0) {
            echo json_encode(['success' => 'Cita eliminada correctamente']);
        } else {
            echo json_encode(['error' => 'No se pudo eliminar la cita. Verifique los datos proporcionados.']);
        }
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al eliminar la cita: ' . $e->getMessage()]);
    }
}
?>







