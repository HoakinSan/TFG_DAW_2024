<?php
session_start();
include 'db.php'; // Asegúrate de que el path es correcto a tu archivo de conexión

header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"), true);

$id_disponibilidad = isset($data['id']) ? $data['id'] : null;

if ($id_disponibilidad) {
    $query = "DELETE FROM disponibilidad_tatuador WHERE id_disponibilidad = ?";
    $stmt = $pdo->prepare($query);
    if ($stmt->execute([$id_disponibilidad])) {
        echo json_encode(['success' => true, 'message' => 'Disponibilidad eliminada correctamente']);
    } else {
        echo json_encode(['success' => false, 'error' => 'No se pudo eliminar la disponibilidad. Verifique los datos proporcionados.']);
    }
} else {
    echo json_encode(['success' => false, 'error' => 'ID de disponibilidad no proporcionado']);
}
?>

