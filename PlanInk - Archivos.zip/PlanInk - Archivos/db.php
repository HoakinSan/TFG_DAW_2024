<?php
$host = 'localhost'; // Host de la base de datos
$dbname = 'calendario-web-v2'; // Nombre de la base de datos
$username = 'josito'; // Usuario de la base de datos
$password = 'admin'; // Contraseña del usuario de la base de datos

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    // Establece el modo de error de PDO a excepción para que los errores se lancen como excepciones
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    // Configurar la conexión para que los datos se reciban y envíen en UTF-8
    $pdo->exec("SET CHARACTER SET utf8");
} catch(PDOException $e) {
    die("No se pudo conectar a la base de datos $dbname: " . $e->getMessage());
}
?>
