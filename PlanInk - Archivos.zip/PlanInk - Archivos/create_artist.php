<?php
session_start();
include 'db.php'; // Verifica que este es el path correcto a tu archivo de conexión

header('Content-Type: application/json');

// Verifica que el usuario está logueado
if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['error' => 'Usuario no autenticado']);
    exit;
}

$id_tatuador = $_SESSION['id_usuario'];

// Obtener el nombre del tatuador desde la base de datos
$stmt = $pdo->prepare("SELECT nombre, apellido1 FROM usuarios WHERE id_usuario = ?");
$stmt->execute([$id_tatuador]);
$tatuador = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$tatuador) {
    echo json_encode(['error' => 'Tatuador no encontrado']);
    exit;
}

$nombre_tatuador = $tatuador['nombre'] . ' ' . $tatuador['apellido1'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['title'], $data['start'], $data['end'], $data['nombre_cliente'])) {
        echo json_encode(['error' => 'Datos insuficientes']);
        exit;
    }

    $titulo = $data['title'];
    $fecha_hora_inicio = $data['start'];
    $fecha_hora_fin = $data['end'];
    $nombre_cliente = $data['nombre_cliente'];
    $id_cliente = isset($data['id_cliente']) ? $data['id_cliente'] : null;

    try {
        if ($id_cliente) {
            $query = "INSERT INTO citas (id_tatuador, nombre_tatuador, id_cliente, titulo, fecha_hora_inicio, fecha_hora_fin, nombre_cliente, is_deleted) VALUES (?, ?, ?, ?, ?, ?, ?, FALSE)";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$id_tatuador, $nombre_tatuador, $id_cliente, $titulo, $fecha_hora_inicio, $fecha_hora_fin, $nombre_cliente]);
        } else {
            $query = "INSERT INTO citas (id_tatuador, nombre_tatuador, titulo, fecha_hora_inicio, fecha_hora_fin, nombre_cliente, is_deleted) VALUES (?, ?, ?, ?, ?, ?, FALSE)";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$id_tatuador, $nombre_tatuador, $titulo, $fecha_hora_inicio, $fecha_hora_fin, $nombre_cliente]);
        }

        echo json_encode(['success' => 'Cita creada correctamente']);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al crear la cita: ' . $e->getMessage()]);
    }
}
?>










