-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 28-05-2024 a las 10:08:22
-- Versión del servidor: 10.4.28-MariaDB
-- Versión de PHP: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `calendario-web-v2`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `citas`
--

CREATE TABLE `citas` (
  `id_cita` int(11) NOT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `titulo` varchar(255) NOT NULL,
  `fecha_hora_inicio` datetime NOT NULL,
  `fecha_hora_fin` datetime NOT NULL,
  `nombre_tatuador` varchar(255) DEFAULT NULL,
  `nombre_cliente` varchar(255) DEFAULT NULL,
  `id_tatuador` int(11) DEFAULT NULL,
  `is_deleted` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `citas`
--

INSERT INTO `citas` (`id_cita`, `id_cliente`, `titulo`, `fecha_hora_inicio`, `fecha_hora_fin`, `nombre_tatuador`, `nombre_cliente`, `id_tatuador`, `is_deleted`) VALUES
(6, 3, 'Evento01', '2024-05-20 14:00:00', '2024-05-20 15:00:00', 'Juan', NULL, NULL, 1),
(7, 3, 'Evento02', '2024-05-20 16:00:00', '2024-05-20 17:00:00', 'Juan', NULL, NULL, 1),
(10, 3, 'Evento03', '2024-05-20 16:00:00', '2024-05-20 17:00:00', 'Pedro', NULL, NULL, 1),
(11, 3, 'Evento04', '2024-05-20 18:00:00', '2024-05-20 19:00:00', '', NULL, NULL, 1),
(12, 3, 'Evento05', '2024-05-20 19:00:00', '2024-05-20 21:00:00', 'Toni Gomez', NULL, 4, 1),
(13, 3, 'Evento06', '2024-05-20 08:00:00', '2024-05-20 09:00:00', 'Pedro Lopez', NULL, 6, 1),
(17, 3, 'Tatto01', '2024-05-22 18:00:00', '2024-05-22 19:00:00', 'Toni Gomez', NULL, 4, 1),
(18, 3, 'Tatto02', '2024-05-22 20:00:00', '2024-05-22 21:00:00', 'Toni Gomez', 'Jose De la Cruz', 4, 1),
(19, 3, 'TattoPruebaDisponibilidad', '2024-05-26 18:00:00', '2024-05-26 19:00:00', 'Toni Gomez', 'Jose De la Cruz', 4, 1),
(20, 3, 'TattoPruebaDisponibilidad2', '2024-06-21 22:00:00', '2024-06-21 23:00:00', 'Toni Gomez', 'Jose De la Cruz', 4, 1),
(21, 3, 'PorElCluloTeLa...', '2024-05-25 12:00:00', '2024-05-25 13:00:00', '', 'Jose De la Cruz', NULL, 1),
(22, 3, 'Prueba02', '2024-05-26 08:00:00', '2024-05-26 09:00:00', '', 'Jose De la Cruz', NULL, 1),
(23, 3, 'PruebaSinTatuador', '2024-05-25 15:00:00', '2024-05-25 15:30:00', '', 'Jose De la Cruz', NULL, 1),
(24, 3, 'Tatto05', '2024-05-25 08:00:00', '2024-05-25 09:00:00', 'Toni Gomez', 'Jose De la Cruz', 4, 1),
(25, 3, 'Barcelona', '2024-05-23 18:00:00', '2024-05-23 19:00:00', 'Marruecos', 'Jose De la Cruz', NULL, 1),
(26, 3, 'TattoDe locos', '2024-05-23 18:00:00', '2024-05-23 19:00:00', 'Toni Gomez', 'Jose De la Cruz', 4, 1),
(27, 3, 'Otro evento más', '2024-05-24 17:00:00', '2024-05-24 17:30:00', 'Toni Gomez', 'Jose De la Cruz', 4, 1),
(33, NULL, 'La mama', '2024-05-22 15:00:00', '2024-05-22 16:00:00', NULL, 'De la mamá', 4, 0),
(34, NULL, 'EL papa', '2024-05-22 15:00:00', '2024-05-22 16:00:00', 'Toni Gomez', 'Del papá', 4, 1),
(35, 3, 'JAJAJAJ', '2024-05-18 18:00:00', '2024-05-18 19:00:00', 'Toni Gomez', 'Jose De la Cruz', 4, 1),
(36, 3, 'Pepe', '2024-05-11 18:00:00', '2024-05-11 19:00:00', 'Toni Gomez', 'Jose De la Cruz', 4, 1),
(37, 3, 'rsgsg', '2024-05-12 18:00:00', '2024-05-12 18:25:00', 'Toni Gomez', 'Jose De la Cruz', 4, 1),
(38, 3, 'Cita01', '2024-05-24 18:00:00', '2024-05-24 19:00:00', 'Pepe', 'Jose De la Cruz', NULL, 1),
(39, 3, 'Cita prueba con Toni', '2024-05-25 18:00:00', '2024-05-25 19:00:00', 'Toni Gomez', 'Jose De la Cruz', 4, 1),
(40, 3, 'Cita otra vez', '2024-05-25 18:00:00', '2024-05-25 19:00:00', 'Toni Gomez', 'Jose De la Cruz', 4, 1),
(41, 3, 'Google', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Toni Gomez', 'Jose De la Cruz', 4, 0),
(42, 3, 'Cita1.1', '0000-00-00 00:00:00', '0000-00-00 00:00:00', 'Pepe', 'Jose De la Cruz', NULL, 0),
(43, 3, 'Cita1.1', '2024-05-24 17:00:00', '2024-05-24 18:00:00', 'Pepe', 'Jose De la Cruz', NULL, 1),
(44, 3, 'Cita de los h', '2024-05-24 16:00:00', '2024-05-24 16:30:00', 'PepeJulia', 'Jose De la Cruz', NULL, 1),
(45, 3, 'Juan', '2024-05-24 16:00:00', '2024-05-24 17:00:00', 'Pedro', 'Jose De la Cruz', NULL, 1),
(46, 3, 'LA Mama del John', '2024-06-19 16:00:00', '2024-06-19 19:00:00', 'Toni Gomez', 'Jose De la Cruz', 4, 1),
(47, 3, 'fdzgfg', '2024-05-24 16:00:00', '2024-05-24 18:00:00', 'gdfgd', 'Jose De la Cruz', NULL, 0),
(48, 3, 'Imademo', '2024-05-26 13:00:00', '2024-05-26 14:30:00', 'Toni Gomez', 'Jose De la Cruz', 4, 1),
(49, 3, 'Imademo2', '2024-05-26 14:30:00', '2024-05-26 15:00:00', 'Pedro Lopez', 'Jose De la Cruz', 6, 0),
(50, NULL, 'fjffn', '2024-05-24 18:00:00', '2024-05-24 20:00:00', 'Toni Gomez', 'No se su nombre', 4, 1),
(51, NULL, 'Agárrame la que me crece', '2024-05-27 19:00:00', '2024-05-27 20:00:00', 'Toni Gomez', 'El número del día', 4, 0),
(52, 7, 'Evento01', '2024-05-27 10:00:00', '2024-05-27 11:00:00', 'Tatuador01', 'Jose Lopez', NULL, 0),
(53, 7, 'Evento02', '2024-05-30 12:00:00', '2024-05-30 15:00:00', 'Toni Gomez', 'Jose Lopez', 4, 0);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `disponibilidad_tatuador`
--

CREATE TABLE `disponibilidad_tatuador` (
  `id_disponibilidad` int(11) NOT NULL,
  `id_tatuador` int(11) NOT NULL,
  `titulo` varchar(255) NOT NULL,
  `fecha_inicio` datetime NOT NULL,
  `fecha_fin` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `disponibilidad_tatuador`
--

INSERT INTO `disponibilidad_tatuador` (`id_disponibilidad`, `id_tatuador`, `titulo`, `fecha_inicio`, `fecha_fin`) VALUES
(5, 4, 'AP7', '2024-05-20 00:00:00', '2024-06-20 00:00:00'),
(8, 4, 'Disponibilidad002', '2024-06-30 00:00:00', '2024-07-28 00:00:00');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_usuario`
--

CREATE TABLE `tipo_usuario` (
  `id_tipo` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tipo_usuario`
--

INSERT INTO `tipo_usuario` (`id_tipo`, `nombre`) VALUES
(1, 'Tatuador'),
(2, 'Cliente'),
(3, 'Gestor');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

CREATE TABLE `usuarios` (
  `id_usuario` int(11) NOT NULL,
  `nombre` varchar(255) NOT NULL,
  `apellido1` varchar(255) NOT NULL,
  `apellido2` varchar(255) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `correo_electronico` varchar(255) NOT NULL,
  `contrasena` varchar(255) NOT NULL,
  `id_tipo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id_usuario`, `nombre`, `apellido1`, `apellido2`, `fecha_nacimiento`, `correo_electronico`, `contrasena`, `id_tipo`) VALUES
(3, 'Jose', 'De la Cruz', 'Bello', '1998-09-26', 'jj@exaple.com', '$2y$10$BW8AX8DFQ6EvWSX3qz1JyOho9nZrttOz7ucFXNuLCk7VbrFWxNPwa', 2),
(4, 'Toni', 'Gomez', 'Lopez', '1998-08-28', 'toni@example.es', '$2y$10$p/kmySHYBlv.ok4cSr5CAeeaaa8PiWwuVJzRcD224x5CqZ3iu4qOK', 1),
(6, 'Pedro', 'Lopez', 'Gomez', '1995-04-17', 'pedro@example.es', '$2y$10$dEX5e2kt.GOiHsxQQDmmzenXkd.W/dfklXl2x2JccyZ79rCMNv9vi', 1),
(7, 'Jose', 'Lopez', 'Perez', '2000-09-12', 'joselopez@example.es', '$2y$10$ho98EG7Hxtt3w8XbaMybz.6u1sxxH3fQmKAUtxfm2L92k.e9FBCJe', 2);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `citas`
--
ALTER TABLE `citas`
  ADD PRIMARY KEY (`id_cita`),
  ADD KEY `fk_cliente` (`id_cliente`),
  ADD KEY `fk_tatuador` (`id_tatuador`);

--
-- Indices de la tabla `disponibilidad_tatuador`
--
ALTER TABLE `disponibilidad_tatuador`
  ADD PRIMARY KEY (`id_disponibilidad`),
  ADD KEY `id_tatuador` (`id_tatuador`);

--
-- Indices de la tabla `tipo_usuario`
--
ALTER TABLE `tipo_usuario`
  ADD PRIMARY KEY (`id_tipo`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id_usuario`),
  ADD UNIQUE KEY `correo_electronico` (`correo_electronico`),
  ADD KEY `fk_tipo_usuario` (`id_tipo`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `citas`
--
ALTER TABLE `citas`
  MODIFY `id_cita` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=54;

--
-- AUTO_INCREMENT de la tabla `disponibilidad_tatuador`
--
ALTER TABLE `disponibilidad_tatuador`
  MODIFY `id_disponibilidad` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de la tabla `tipo_usuario`
--
ALTER TABLE `tipo_usuario`
  MODIFY `id_tipo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `citas`
--
ALTER TABLE `citas`
  ADD CONSTRAINT `fk_cliente` FOREIGN KEY (`id_cliente`) REFERENCES `usuarios` (`id_usuario`),
  ADD CONSTRAINT `fk_tatuador` FOREIGN KEY (`id_tatuador`) REFERENCES `usuarios` (`id_usuario`);

--
-- Filtros para la tabla `disponibilidad_tatuador`
--
ALTER TABLE `disponibilidad_tatuador`
  ADD CONSTRAINT `disponibilidad_tatuador_ibfk_1` FOREIGN KEY (`id_tatuador`) REFERENCES `usuarios` (`id_usuario`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `fk_tipo_usuario` FOREIGN KEY (`id_tipo`) REFERENCES `tipo_usuario` (`id_tipo`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
