<?php
session_start();
include 'db.php'; // Verifica que este es el path correcto a tu archivo de conexión

header('Content-Type: application/json');

// Verifica que el usuario está logueado
if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['error' => 'Usuario no autenticado']);
    exit;
}

$id_cliente = $_SESSION['id_usuario'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['title'], $data['start'], $data['end'], $data['nombre_tatuador'])) {
        echo json_encode(['error' => 'Datos insuficientes']);
        exit;
    }

    // Obtener el nombre del cliente desde la base de datos
    $stmt = $pdo->prepare("SELECT nombre, apellido1 FROM usuarios WHERE id_usuario = ? AND id_tipo = 2");
    $stmt->execute([$id_cliente]);
    $cliente = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$cliente) {
        echo json_encode(['error' => 'Cliente no encontrado']);
        exit;
    }

    $nombre_cliente = $cliente['nombre'] . ' ' . $cliente['apellido1'];
    $titulo = $data['title'];
    $fecha_hora_inicio = $data['start'];
    $fecha_hora_fin = $data['end'];
    $id_tatuador = isset($data['id_tatuador']) ? $data['id_tatuador'] : null;
    $nombre_tatuador = $data['nombre_tatuador'];

    try {
        // Verificar superposición de citas
        $stmt = $pdo->prepare("SELECT COUNT(*) FROM citas WHERE id_tatuador = ? AND ((fecha_hora_inicio < ? AND fecha_hora_fin > ?) OR (fecha_hora_inicio < ? AND fecha_hora_fin > ?) OR (fecha_hora_inicio >= ? AND fecha_hora_fin <= ?))");
        $stmt->execute([$id_tatuador, $fecha_hora_fin, $fecha_hora_inicio, $fecha_hora_fin, $fecha_hora_inicio, $fecha_hora_inicio, $fecha_hora_fin]);
        $count = $stmt->fetchColumn();

        if ($count > 0) {
            echo json_encode(['error' => 'Ya existe una cita en este horario.']);
            exit;
        }

        $query = "INSERT INTO citas (id_cliente, nombre_cliente, titulo, fecha_hora_inicio, fecha_hora_fin, id_tatuador, nombre_tatuador) VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$id_cliente, $nombre_cliente, $titulo, $fecha_hora_inicio, $fecha_hora_fin, $id_tatuador, $nombre_tatuador]);

        echo json_encode(['success' => 'Cita creada correctamente']);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al crear la cita: ' . $e->getMessage()]);
    }
}
?>








