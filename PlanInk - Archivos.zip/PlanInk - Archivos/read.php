<?php
session_start();
include 'db.php'; // Verifica que este es el path correcto a tu archivo de conexión

header('Content-Type: application/json');

// Verifica que el usuario está logueado
if (!isset($_SESSION['id_usuario'])) {
    echo json_encode([]);
    exit;
}

$id_cliente = $_SESSION['id_usuario'];

try {
    $query = "SELECT id_cita AS id, titulo AS title, fecha_hora_inicio AS start, fecha_hora_fin AS end, nombre_tatuador, id_tatuador FROM citas WHERE id_cliente = ? AND is_deleted = FALSE";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id_cliente]);
    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($eventos);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error al recuperar eventos: ' . $e->getMessage()]);
}
?>

