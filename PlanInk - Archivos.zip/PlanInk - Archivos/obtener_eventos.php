<?php
session_start();
include 'db.php'; // Verifica que este es el path correcto a tu archivo de conexión

header('Content-Type: application/json');

// Verifica que el usuario está logueado
if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['error' => 'Usuario no autenticado']);
    exit;
}

$id_cliente = $_SESSION['id_usuario'];

try {
    $query = "SELECT id_cita, titulo, fecha_hora_inicio, fecha_hora_fin, nombre_tatuador FROM citas WHERE id_cliente = ? AND is_deleted = FALSE";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id_cliente]);
    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $formattedEvents = [];
    foreach ($eventos as $evento) {
        $start = new DateTime($evento['fecha_hora_inicio']);
        $end = new DateTime($evento['fecha_hora_fin']);
        $formattedEvents[] = [
            'day' => (int)$start->format('d'),
            'month' => (int)$start->format('m'),
            'year' => (int)$start->format('Y'),
            'events' => [[
                'id' => $evento['id_cita'],
                'title' => $evento['titulo'],
                'start' => $evento['fecha_hora_inicio'],
                'end' => $evento['fecha_hora_fin'],
                'nombre_tatuador' => $evento['nombre_tatuador']
            ]]
        ];
    }

    echo json_encode(['success' => true, 'events' => $formattedEvents]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error al recuperar eventos: ' . $e->getMessage()]);
}
?>


