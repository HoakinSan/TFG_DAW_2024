<?php
session_start();
include 'db.php'; // Verifica que este es el path correcto a tu archivo de conexión

header('Content-Type: application/json');

// Verifica que el usuario está logueado
if (!isset($_SESSION['id_usuario'])) {
    echo json_encode(['error' => 'Usuario no autenticado']);
    exit;
}

$id_cliente = $_SESSION['id_usuario'];

if ($_SERVER['REQUEST_METHOD'] === 'PUT') {
    $data = json_decode(file_get_contents('php://input'), true);

    if (!isset($data['id'], $data['title'], $data['start'], $data['end'], $data['nombre_tatuador'], $data['id_tatuador'])) {
        echo json_encode(['error' => 'Datos insuficientes']);
        exit;
    }

    $id_cita = $data['id'];
    $titulo = $data['title'];
    $fecha_hora_inicio = $data['start'];
    $fecha_hora_fin = $data['end'];
    $nombre_tatuador = $data['nombre_tatuador'];
    $id_tatuador = $data['id_tatuador'];

    try {
        $query = "UPDATE citas SET titulo = ?, fecha_hora_inicio = ?, fecha_hora_fin = ?, nombre_tatuador = ?, id_tatuador = ? WHERE id_cita = ? AND id_cliente = ?";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$titulo, $fecha_hora_inicio, $fecha_hora_fin, $nombre_tatuador, $id_tatuador, $id_cita, $id_cliente]);

        echo json_encode(['success' => 'Cita actualizada correctamente']);
    } catch (PDOException $e) {
        http_response_code(500);
        echo json_encode(['error' => 'Error al actualizar la cita: ' . $e->getMessage()]);
    }
}
?>
