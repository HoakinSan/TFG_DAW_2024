<?php
session_start();
include 'db.php'; // Verifica que este es el path correcto a tu archivo de conexión

header('Content-Type: application/json');

// Verifica que el usuario está logueado y es tatuador
if (!isset($_SESSION['id_usuario']) || $_SESSION['id_tipo'] != 1) {
    echo json_encode(['error' => 'Usuario no autenticado o no autorizado']);
    exit;
}

$id_tatuador = $_SESSION['id_usuario'];

try {
    $query = "SELECT id_cita, titulo, fecha_hora_inicio, fecha_hora_fin, nombre_cliente FROM citas WHERE id_tatuador = ? AND is_deleted = FALSE";
    $stmt = $pdo->prepare($query);
    $stmt->execute([$id_tatuador]);
    $eventos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $formattedEvents = [];
    foreach ($eventos as $evento) {
        $start = new DateTime($evento['fecha_hora_inicio']);
        $end = new DateTime($evento['fecha_hora_fin']);
        $formattedEvents[] = [
            'day' => (int)$start->format('d'),
            'month' => (int)$start->format('m'),
            'year' => (int)$start->format('Y'),
            'events' => [[
                'id' => $evento['id_cita'],
                'title' => $evento['titulo'],
                'start' => $evento['fecha_hora_inicio'],
                'end' => $evento['fecha_hora_fin'],
                'nombre_cliente' => $evento['nombre_cliente']
            ]]
        ];
    }

    echo json_encode(['success' => true, 'events' => $formattedEvents]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'Error al recuperar eventos: ' . $e->getMessage()]);
}
?>


