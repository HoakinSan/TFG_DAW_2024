<?php
// Inicia la sesión
session_start();

// Verifica si las variables de sesión específicas están definidas antes de usarlas
if (isset($_SESSION['id_usuario']) && isset($_SESSION['nombre']) && isset($_SESSION['apellido1'])) {
    // Ahora es seguro usar $_SESSION['id_usuario'], $_SESSION['nombre'], $_SESSION['apellido1']
    $saludo = "Bienvenido " . $_SESSION['nombre'] . " " . $_SESSION['apellido1'];
} else {
    // Si las variables de sesión no están definidas, redirige al usuario al login o maneja el error
    header('Location: ../../Usuarios/inicio.php'); // Ajusta la ruta según sea necesario
    exit();
}

// Obtén los datos del usuario desde la sesión
$id_usuario = $_SESSION['id_usuario'];
$nombre = $_SESSION['nombre'];
$apellido1 = $_SESSION['apellido1'];
$id_tipo = $_SESSION['id_tipo']; // Aquí es donde asignamos $id_tipo

echo "<script>
    var idUsuario = '$id_usuario';
    var nombreUsuario = '$nombre';
    var apellidoUsuario = '$apellido1';
    var idTipo = '$id_tipo';
</script>";

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="style.css">
    <title>Calendario con eventos</title>
</head>

<body>

    <h1>Bienvenido, <?php echo htmlspecialchars($_SESSION['nombre']); ?></h1>
    <p>Has iniciado sesión correctamente.</p>

    <div class="calendar-container">
        <div class="container">
            <div class="left">
                <div class="calendar">
                    <div class="month">
                        <i class="fas fa-angle-left prev"></i>
                        <div class="date"></div>
                        <i class="fas fa-angle-right next"></i>
                    </div>
                    <div class="weekdays">
                        <div>Lunes</div>
                        <div>Martes</div>
                        <div>Miércoles</div>
                        <div>Jueves</div>
                        <div>Viernes</div>
                        <div>Sábado</div>
                        <div>Domingo</div>
                    </div>
                    <div class="days"></div>
                    <div class="goto-today">
                        <div class="goto">
                            <input type="text" placeholder="mm/yyyy" class="date-input" />
                            <button class="goto-btn">Ir</button>
                        </div>
                        <button class="today-btn">Hoy</button>
                    </div>
                </div>
            </div>
            <div class="right">
                <div class="today-date">
                    <div class="event-day"></div>
                    <div class="event-date"></div>
                </div>

                <div class="events"></div>

                <!-- Botón y formulario para clientes -->
                <?php if ($_SESSION['id_tipo'] == '2') : ?>
                    <div class="right-button">
                        <button class="add-event">
                            <i class="fas fa-plus"></i>
                        </button>
                        <div class="add-event-select">
                            <select class="tatuador-select">
                                <option value="">Seleccione un tatuador</option>
                                <!-- Aquí se cargan dinámicamente los tatuadores -->
                            </select>
                        </div>
                    </div>

                    <div class="add-event-wrapper">
                        <!-- Formulario para añadir evento -->
                        <div class="add-event-header">
                            <span class="title">Crear Evento</span>
                            <span class="close">&times;</span>
                        </div>
                        <div class="add-event-body">
                            <div class="add-event-input">
                                <input type="text" class="event-name" placeholder="Título del evento">
                            </div>
                            <div class="add-event-input">
                                <input type="text" class="event-time-from" placeholder="Hora de inicio (HH:MM)">
                            </div>
                            <div class="add-event-input">
                                <input type="text" class="event-time-to" placeholder="Hora de fin (HH:MM)">
                            </div>
                            <div class="add-event-input">
                                <input type="text" class="tatuador-name" placeholder="Nombre del tatuador">
                            </div>
                        </div>
                        <div class="add-event-footer">
                            <button class="add-event-btn">Añadir Evento</button>
                        </div>
                    </div>
                <?php endif; ?>


                <?php if ($_SESSION['id_tipo'] == '1') : ?>
                    <!-- Botón y formulario para tatuadores -->
                    <div class="right-button">
                        <button class="add-availability">
                            <i class="fas fa-calendar-alt"></i>
                        </button>
                        <button class="add-event-artist">
                            <i class="fas fa-plus"></i>
                        </button>
                    </div>

                    <div class="add-event-artist-wrapper">
                        <!-- Formulario para añadir evento -->
                        <div class="add-event-artist-header">
                            <span class="title">Crear Evento</span>
                            <span class="close">&times;</span>
                        </div>
                        <div class="add-event-artist-body">
                            <div class="add-event-artist-input">
                                <input type="text" class="event-name" placeholder="Título del evento">
                            </div>
                            <div class="add-event-artist-input">
                                <input type="text" class="event-time-from" placeholder="Hora de inicio (HH:MM)">
                            </div>
                            <div class="add-event-artist-input">
                                <input type="text" class="event-time-to" placeholder="Hora de fin (HH:MM)">
                            </div>
                            <div class="add-event-artist-input">
                                <input type="text" class="cliente-name" placeholder="Nombre del cliente">
                            </div>
                        </div>
                        <div class="add-event-artist-footer">
                            <button class="add-event-artist-btn">Añadir Evento</button>
                        </div>
                    </div>

                    <div class="add-availability-wrapper">
                        <!-- Formulario para añadir disponibilidad -->
                        <div class="add-availability-header">
                            <span class="title">Crear Disponibilidad</span>
                            <span class="close">&times;</span>
                        </div>
                        <div class="add-availability-body">
                            <div class="add-availability-input">
                                <input type="text" class="availability-title" placeholder="Título de la disponibilidad">
                            </div>
                            <div class="add-availability-input">
                                <input type="date" class="availability-start">
                            </div>
                            <div class="add-availability-input">
                                <input type="date" class="availability-end">
                            </div>
                        </div>
                        <div class="add-availability-footer">
                            <button class="add-availability-btn">Añadir Disponibilidad</button>
                        </div>
                    </div>
                <?php endif; ?>

            </div>
        </div>

        <!-- HTML: Sección de Agendas Abiertas -->
        <div id="agendas-abiertas" class="agendas-container" style="display: none;">
            <h2>Agendas Abiertas</h2>
            <div class="agendas-list"></div>
        </div>


        <div class="hourly-events-container">
            <h3>Horario</h3>
            <div class="hourly-events">
                <!-- Aquí se mostrarán los eventos por horas -->
            </div>
        </div>
    </div>

    <div>
        <p></p>
    </div>

    <form action="../../Usuarios/logout.php" method="post" class="logout-container">
        <button class="logout-btn" type="submit">Cerrar Sesión</button>
    </form>

    <script src="script.js"></script>
</body>

</html>